const sqlite3 = require("sqlite3").verbose();
const path = require("path");
const fs = require("fs");

// Use DB_PATH from environment for production (cPanel) or fallback to local path
const dbPath = process.env.DB_PATH || path.join(__dirname, "..", "data", "verifications.db");
const dbDir = path.dirname(dbPath);

// Ensure database directory exists
if (!fs.existsSync(dbDir)) {
  fs.mkdirSync(dbDir, { recursive: true });
}

console.log(`Using database at: ${dbPath}`);

const db = new sqlite3.Database(dbPath, (err) => {
  if (err) {
    console.error("Database connection error:", err.message);
    throw err;
  }
  console.log("Connected to SQLite database");
});

db.serialize(() => {
  db.run(`
    CREATE TABLE IF NOT EXISTS verifications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      session_id TEXT UNIQUE NOT NULL,
      name TEXT NOT NULL,
      email TEXT NOT NULL,
      pin_number TEXT NOT NULL,
      status TEXT NOT NULL,
      code TEXT,
      verified TEXT,
      transaction_guid TEXT,
      person_data TEXT,
      request_data TEXT,
      response_data TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  db.run(
    `CREATE INDEX IF NOT EXISTS idx_session_id ON verifications(session_id)`
  );
  db.run(`CREATE INDEX IF NOT EXISTS idx_email ON verifications(email)`);
  db.run(`CREATE INDEX IF NOT EXISTS idx_status ON verifications(status)`);
  db.run(
    `CREATE INDEX IF NOT EXISTS idx_created_at ON verifications(created_at DESC)`
  );

  db.run(`
    CREATE TABLE IF NOT EXISTS admin_users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);
});

function createVerification({
  sessionId,
  name,
  email,
  pinNumber,
  status,
  code,
  verified,
  transactionGuid,
  personData,
  requestData,
  responseData,
}) {
  return new Promise((resolve, reject) => {
    db.run(
      `
      INSERT INTO verifications (
        session_id, name, email, pin_number, status, code, verified,
        transaction_guid, person_data, request_data, response_data
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `,
      [
        sessionId,
        name || "",
        email || "",
        pinNumber || "",
        status,
        code || null,
        verified || null,
        transactionGuid || null,
        personData ? JSON.stringify(personData) : null,
        requestData ? JSON.stringify(requestData) : null,
        responseData ? JSON.stringify(responseData) : null,
      ],
      function (err) {
        if (err) return reject(err);
        resolve(this.lastID);
      }
    );
  });
}

function getVerificationBySessionId(sessionId) {
  return new Promise((resolve, reject) => {
    db.get(
      "SELECT * FROM verifications WHERE session_id = ?",
      [sessionId],
      (err, row) => {
        if (err) return reject(err);
        resolve(row);
      }
    );
  });
}

function getAllVerifications(limit = 100, offset = 0) {
  return new Promise((resolve, reject) => {
    db.all(
      `SELECT * FROM verifications ORDER BY created_at DESC LIMIT ? OFFSET ?`,
      [limit, offset],
      (err, rows) => {
        if (err) return reject(err);
        resolve(rows || []);
      }
    );
  });
}

function getVerificationStats() {
  return new Promise((resolve, reject) => {
    db.get("SELECT COUNT(*) as total FROM verifications", (err, row1) => {
      if (err) return reject(err);
      db.get(
        "SELECT COUNT(*) as approved FROM verifications WHERE status = 'approved'",
        (err, row2) => {
          if (err) return reject(err);
          db.get(
            "SELECT COUNT(*) as failed FROM verifications WHERE status = 'failed'",
            (err, row3) => {
              if (err) return reject(err);
              db.get(
                "SELECT COUNT(*) as pending FROM verifications WHERE status = 'pending'",
                (err, row4) => {
                  if (err) return reject(err);
                  resolve({
                    total: row1?.total || 0,
                    approved: row2?.approved || 0,
                    failed: row3?.failed || 0,
                    pending: row4?.pending || 0,
                  });
                }
              );
            }
          );
        }
      );
    });
  });
}

function searchVerifications(query) {
  return new Promise((resolve, reject) => {
    const searchTerm = `%${query}%`;
    db.all(
      `SELECT * FROM verifications WHERE name LIKE ? OR email LIKE ? OR pin_number LIKE ? ORDER BY created_at DESC LIMIT 50`,
      [searchTerm, searchTerm, searchTerm],
      (err, rows) => {
        if (err) return reject(err);
        resolve(rows || []);
      }
    );
  });
}

function getAdminByUsername(username) {
  return new Promise((resolve, reject) => {
    db.get(
      "SELECT * FROM admin_users WHERE username = ?",
      [username],
      (err, row) => {
        if (err) return reject(err);
        resolve(row);
      }
    );
  });
}

function createAdminUser(username, passwordHash) {
  return new Promise((resolve, reject) => {
    db.run(
      "INSERT INTO admin_users (username, password_hash) VALUES (?, ?)",
      [username, passwordHash],
      function (err) {
        if (err) return reject(err);
        resolve(this.lastID);
      }
    );
  });
}

module.exports = {
  db,
  createVerification,
  getVerificationBySessionId,
  getAllVerifications,
  getVerificationStats,
  searchVerifications,
  getAdminByUsername,
  createAdminUser,
};
